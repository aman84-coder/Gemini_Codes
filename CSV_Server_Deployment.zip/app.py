from flask import Flask, render_template, request, redirect, url_for, flash, abort, send_file
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import pandas as pd
import os
import json
import logging
import sys
import io
from datetime import datetime

app = Flask(__name__)
# SECURITY NOTE: Change this in production
app.secret_key = 'super_secret_key_change_me'

# --- LOGGING SETUP (For Apache) ---
if __name__ != '__main__':
    logging.basicConfig(stream=sys.stderr, level=logging.ERROR)

# --- CONFIGURATION (FIXED FOR APACHE) ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USER_DB = os.path.join(BASE_DIR, 'users.json')
CSV_FOLDER = os.path.join(BASE_DIR, 'csv_files')

if not os.path.exists(CSV_FOLDER):
    os.makedirs(CSV_FOLDER)

# --- Login Setup ---
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin):
    def __init__(self, id):
        self.id = id
        self.is_admin = (id == 'admin')

    def __repr__(self):
        return self.id

@login_manager.user_loader
def load_user(user_id):
    users = load_users()
    if user_id in users:
        return User(user_id)
    return None

# --- Helper Functions ---
def load_users():
    if not os.path.exists(USER_DB): return {}
    try:
        with open(USER_DB, 'r') as f: return json.load(f)
    except (json.JSONDecodeError, IOError): return {}

def save_users(users):
    try:
        with open(USER_DB, 'w') as f: json.dump(users, f)
    except IOError as e:
        app.logger.error(f"Error saving users: {e}")

def read_csv_safe(file_path):
    try:
        return pd.read_csv(file_path, on_bad_lines='skip').fillna('NA')
    except UnicodeDecodeError:
        try:
            return pd.read_csv(file_path, on_bad_lines='skip', encoding='ISO-8859-1').fillna('NA')
        except Exception:
            return pd.read_csv(file_path, on_bad_lines='skip', encoding='cp1252').fillna('NA')

# --- Routes: Auth ---
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated: return redirect(url_for('index'))
    if request.method == 'POST':
        username, password = request.form['username'], request.form['password']
        users = load_users()
        if username in users and check_password_hash(users[username], password):
            login_user(User(username))
            return redirect(request.args.get('next') or url_for('index'))
        flash('Invalid username or password', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# --- Routes: Main App ---
@app.route('/')
@login_required
def index():
    files_data = []
    if os.path.exists(CSV_FOLDER):
        for filename in os.listdir(CSV_FOLDER):
            if filename.endswith('.csv'):
                file_path = os.path.join(CSV_FOLDER, filename)
                try:
                    timestamp = os.path.getmtime(file_path)
                    date_str = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
                except OSError:
                    date_str = "Unknown"
                files_data.append({'name': filename, 'updated': date_str})
    
    files_data.sort(key=lambda x: x['updated'], reverse=True)
    return render_template('file_list.html', files=files_data, user=current_user)

@app.route('/view/<filename>', methods=['GET', 'POST'])
@login_required
def view_file(filename):
    if '..' in filename or filename.startswith('/'): abort(400)
    file_path = os.path.join(CSV_FOLDER, filename)
    if not os.path.exists(file_path): 
        flash("File not found.", "danger")
        return redirect(url_for('index'))

    try:
        timestamp = os.path.getmtime(file_path)
        file_date = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
    except OSError:
        file_date = "Unknown"

    try:
        df = read_csv_safe(file_path)
        columns = df.columns.tolist()
        data = df.values.tolist()

        pivot_html, pivot_error = None, None
        sel_index = request.form.get('index', columns[0] if columns else '')
        sel_columns = request.form.get('columns', '')
        sel_values = request.form.get('values', columns[-1] if columns else '')
        sel_agg = request.form.get('aggfunc', 'sum')

        if request.method == 'POST':
            try:
                cols_param = sel_columns if sel_columns else None
                pt = pd.pivot_table(df, index=sel_index, columns=cols_param, values=sel_values, aggfunc=sel_agg).fillna(0)
                pivot_html = pt.to_html(classes='table table-bordered table-sm table-hover', border=0)
            except Exception as e:
                pivot_error = f"Pivot Error: {e}"

        return render_template('view_csv.html', filename=filename, file_date=file_date, columns=columns, data=data,
                               pivot_html=pivot_html, pivot_error=pivot_error, sel_index=sel_index, sel_columns=sel_columns, sel_values=sel_values, sel_agg=sel_agg)
    except pd.errors.EmptyDataError:
        flash("This CSV file is empty.", "warning")
        return redirect(url_for('index'))
    except Exception as e:
        app.logger.error(f"Error viewing file {filename}: {e}")
        flash("An unexpected error occurred while reading the file.", "danger")
        return redirect(url_for('index'))

# --- Routes: S3 Dashboard ---
@app.route('/s3-dashboard')
@login_required
def s3_dashboard():
    lens_file = os.path.join(CSV_FOLDER, 'storage_lens.csv')
    if not os.path.exists(lens_file):
        flash("Storage Lens CSV not found.", "warning")
        return redirect(url_for('index'))

    try:
        df = read_csv_safe(lens_file)
        total_capacity = round(df['Total_Size_GB'].sum(), 2)
        account_capacity = df.groupby('AccountId')['Total_Size_GB'].sum()
        highest_account = account_capacity.idxmax() if not account_capacity.empty else "N/A"
        
        tiers = ['DEEP_ARCHIVE_GB', 'GLACIER_IR_GB', 'INTELLIGENT_TIERING_GB', 'ONEZONE_IA_GB', 'STANDARD_GB', 'STANDARD_IA_GB']
        tier_data = {tier: round(df[tier].sum(), 2) for tier in tiers if tier in df.columns}

        top_n = max(1, min(request.args.get('top', 10, type=int), 20)) 
        top_growth_df = df.nlargest(top_n, 'Growth_GB')[['BucketName', 'Growth_GB']]

        return render_template('s3_dashboard.html', total_capacity=total_capacity, highest_account=highest_account,
                               tier_labels=list(tier_data.keys()), tier_values=list(tier_data.values()),
                               top_growth_labels=top_growth_df['BucketName'].tolist(), top_growth_values=top_growth_df['Growth_GB'].tolist(), top_n=top_n)
    except Exception as e:
        app.logger.error(f"Error generating S3 dashboard: {e}")
        flash("An error occurred while processing the Storage Lens data.", "danger")
        return redirect(url_for('index'))

@app.route('/export-capacity-report')
@login_required
def export_capacity_report():
    lens_file = os.path.join(CSV_FOLDER, 'storage_lens.csv')
    if not os.path.exists(lens_file): return redirect(url_for('s3_dashboard'))

    try:
        df = read_csv_safe(lens_file)
        
        summary_df = pd.DataFrame({
            'Metric': ['Total S3 Capacity (GB)', 'Highest Capacity Account'],
            'Value': [round(df['Total_Size_GB'].sum(), 2), df.groupby('AccountId')['Total_Size_GB'].sum().idxmax()]
        })

        tiers = ['DEEP_ARCHIVE_GB', 'GLACIER_IR_GB', 'INTELLIGENT_TIERING_GB', 'ONEZONE_IA_GB', 'STANDARD_GB', 'STANDARD_IA_GB']
        tier_data = {'Storage Tier': [t for t in tiers if t in df.columns], 'Total Capacity (GB)': [round(df[t].sum(), 2) for t in tiers if t in df.columns]}
        tiers_df = pd.DataFrame(tier_data)

        available_cols = [c for c in ['AccountId', 'BucketName', 'Total_Size_GB', 'Growth_GB', '30-day%Growth'] if c in df.columns]
        top_growth_df = df.nlargest(20, 'Growth_GB')[available_cols]

        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
            tiers_df.to_excel(writer, sheet_name='Capacity By Tier', index=False)
            top_growth_df.to_excel(writer, sheet_name='Top 20 Growth', index=False)
            df.to_excel(writer, sheet_name='Raw Data', index=False)

        output.seek(0)
        filename = f"S3_Capacity_Report_{datetime.today().strftime('%Y-%m-%d')}.xlsx"
        return send_file(output, download_name=filename, as_attachment=True)
    except Exception as e:
        app.logger.error(f"Error generating Excel: {e}")
        return redirect(url_for('s3_dashboard'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
