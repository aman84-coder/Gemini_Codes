from flask import Flask, render_template, request, redirect, url_for, flash, abort, send_file
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import pandas as pd
import os
import json
import logging
import sys
import io
from datetime import datetime

app = Flask(__name__)
# SECURITY NOTE: Change this in production
app.secret_key = 'super_secret_key_change_me'

# --- LOGGING SETUP (For Apache) ---
if __name__ != '__main__':
    logging.basicConfig(stream=sys.stderr, level=logging.ERROR)

# --- CONFIGURATION (FIXED FOR APACHE) ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USER_DB = os.path.join(BASE_DIR, 'users.json')
CSV_FOLDER = os.path.join(BASE_DIR, 'csv_files')

if not os.path.exists(CSV_FOLDER):
    os.makedirs(CSV_FOLDER)

# --- Login Setup ---
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin):
    def __init__(self, id):
        self.id = id
        self.is_admin = (id == 'admin')

    def __repr__(self):
        return self.id

@login_manager.user_loader
def load_user(user_id):
    users = load_users()
    if user_id in users:
        return User(user_id)
    return None

# --- Helper Functions ---
def load_users():
    if not os.path.exists(USER_DB): return {}
    try:
        with open(USER_DB, 'r') as f: return json.load(f)
    except (json.JSONDecodeError, IOError): return {}

def save_users(users):
    try:
        with open(USER_DB, 'w') as f: json.dump(users, f)
    except IOError as e:
        app.logger.error(f"Error saving users: {e}")

def read_csv_safe(file_path):
    try:
        return pd.read_csv(file_path, on_bad_lines='skip').fillna('NA')
    except UnicodeDecodeError:
        try:
            return pd.read_csv(file_path, on_bad_lines='skip', encoding='ISO-8859-1').fillna('NA')
        except Exception:
            return pd.read_csv(file_path, on_bad_lines='skip', encoding='cp1252').fillna('NA')

def get_combined_lens_data():
    """Finds all storage lens CSVs and combines them into one DataFrame."""
    lens_files = [f for f in os.listdir(CSV_FOLDER) if f.endswith('.csv') and 'storage_lens' in f.lower()]
    if not lens_files: return None
        
    dfs = []
    for file in lens_files:
        file_path = os.path.join(CSV_FOLDER, file)
        try:
            df = read_csv_safe(file_path)
            dfs.append(df)
        except Exception as e:
            app.logger.error(f"Failed to read {file}: {e}")
            
    if not dfs: return None

    combined_df = pd.concat(dfs, ignore_index=True)
    if 'BucketName' in combined_df.columns:
        combined_df = combined_df.drop_duplicates(subset=['BucketName'])
        
    return combined_df

# --- Routes: Auth ---
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated: return redirect(url_for('index'))
    if request.method == 'POST':
        username, password = request.form['username'], request.form['password']
        users = load_users()
        if username in users and check_password_hash(users[username], password):
            login_user(User(username))
            return redirect(request.args.get('next') or url_for('index'))
        flash('Invalid username or password', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# --- Routes: Main App ---
@app.route('/')
@login_required
def index():
    files_data = []
    if os.path.exists(CSV_FOLDER):
        for filename in os.listdir(CSV_FOLDER):
            if filename.endswith('.csv'):
                file_path = os.path.join(CSV_FOLDER, filename)
                try:
                    timestamp = os.path.getmtime(file_path)
                    date_str = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
                except OSError:
                    date_str = "Unknown"
                files_data.append({'name': filename, 'updated': date_str})
    
    files_data.sort(key=lambda x: x['updated'], reverse=True)
    return render_template('file_list.html', files=files_data, user=current_user)

@app.route('/view/<filename>', methods=['GET', 'POST'])
@login_required
def view_file(filename):
    if '..' in filename or filename.startswith('/'): abort(400)
    file_path = os.path.join(CSV_FOLDER, filename)
    if not os.path.exists(file_path): 
        flash("File not found.", "danger")
        return redirect(url_for('index'))

    try:
        timestamp = os.path.getmtime(file_path)
        file_date = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
    except OSError:
        file_date = "Unknown"

    try:
        df = read_csv_safe(file_path)
        columns = df.columns.tolist()
        data = df.values.tolist()

        pivot_html, pivot_error = None, None
        sel_index = request.form.get('index', columns[0] if columns else '')
        sel_columns = request.form.get('columns', '')
        sel_values = request.form.get('values', columns[-1] if columns else '')
        sel_agg = request.form.get('aggfunc', 'sum')

        if request.method == 'POST':
            try:
                cols_param = sel_columns if sel_columns else None
                pt = pd.pivot_table(df, index=sel_index, columns=cols_param, values=sel_values, aggfunc=sel_agg).fillna(0)
                pivot_html = pt.to_html(classes='table table-bordered table-sm table-hover', border=0)
            except Exception as e:
                pivot_error = f"Pivot Error: {e}"

        return render_template('view_csv.html', filename=filename, file_date=file_date, columns=columns, data=data,
                               pivot_html=pivot_html, pivot_error=pivot_error, sel_index=sel_index, sel_columns=sel_columns, sel_values=sel_values, sel_agg=sel_agg)
    except pd.errors.EmptyDataError:
        flash("This CSV file is empty.", "warning")
        return redirect(url_for('index'))
    except Exception as e:
        app.logger.error(f"Error viewing file {filename}: {e}")
        flash("An unexpected error occurred while reading the file.", "danger")
        return redirect(url_for('index'))

@app.route('/analyze/<filename>', methods=['GET', 'POST'])
@login_required
def analyze_file(filename):
    if '..' in filename or filename.startswith('/'): abort(400)
    file_path = os.path.join(CSV_FOLDER, filename)
    if not os.path.exists(file_path):
        flash("File not found.", "danger")
        return redirect(url_for('index'))

    try:
        df = read_csv_safe(file_path)
        # Stats
        columns = df.columns.tolist()
        rows = df.shape[0]
        cols_count = df.shape[1]
        missing_values = df.isnull().sum().sum()
        file_size_kb = round(os.path.getsize(file_path) / 1024, 2)
        data_types = df.dtypes.astype(str).to_dict()

        numerical_df = df.describe()
        numerical_summary = numerical_df.to_html(classes='table table-bordered table-hover table-sm', border=0, float_format='%.2f') if not numerical_df.empty else None
        head_preview = df.head().to_html(classes='table table-striped table-sm', border=0, index=False)

        # Pivot
        pivot_html = None
        pivot_error = None
        sel_index = request.form.get('index', columns[0] if columns else '')
        sel_columns = request.form.get('columns', '')
        sel_values = request.form.get('values', columns[-1] if columns else '')
        sel_agg = request.form.get('aggfunc', 'sum')

        if request.method == 'POST':
            try:
                cols_param = sel_columns if sel_columns else None
                pt = pd.pivot_table(df, index=sel_index, columns=cols_param, values=sel_values, aggfunc=sel_agg).fillna(0)
                pivot_html = pt.to_html(classes='table table-bordered table-sm table-hover', border=0)
            except Exception as e:
                pivot_error = f"Pivot Error: {e}"

        return render_template('analyze.html',
                               filename=filename,
                               rows=rows, cols=cols_count, columns=columns,
                               missing_values=missing_values, file_size=file_size_kb,
                               data_types=data_types, numerical_summary=numerical_summary,
                               head_preview=head_preview,
                               pivot_html=pivot_html, pivot_error=pivot_error,
                               sel_index=sel_index, sel_columns=sel_columns, sel_values=sel_values, sel_agg=sel_agg,
                               user=current_user.id)
    except Exception as e:
        app.logger.error(f"Error analyzing file {filename}: {e}")
        flash("An unexpected error occurred while analyzing the file.", "danger")
        return redirect(url_for('index'))

# --- Routes: S3 Dashboard ---
@app.route('/s3-dashboard')
@login_required
def s3_dashboard():
    df = get_combined_lens_data()
    
    if df is None or df.empty:
        flash("No Storage Lens CSV files found. Please ensure files include 'storage_lens' in their name.", "warning")
        return redirect(url_for('index'))

    try:
        total_capacity = round(df['Total_Size_GB'].sum(), 2)
        account_capacity = df.groupby('AccountId')['Total_Size_GB'].sum()
        highest_account = account_capacity.idxmax() if not account_capacity.empty else "N/A"
        
        tiers = ['DEEP_ARCHIVE_GB', 'GLACIER_IR_GB', 'INTELLIGENT_TIERING_GB', 'ONEZONE_IA_GB', 'STANDARD_GB', 'STANDARD_IA_GB']
        tier_data = {tier: round(df[tier].sum(), 2) for tier in tiers if tier in df.columns}

        top_n = max(1, min(request.args.get('top', 10, type=int), 20)) 
        
        if 'Growth_GB' in df.columns:
            top_growth_df = df.nlargest(top_n, 'Growth_GB')[['BucketName', 'Growth_GB']]
        else:
            top_growth_df = pd.DataFrame(columns=['BucketName', 'Growth_GB'])

        return render_template('s3_dashboard.html', total_capacity=total_capacity, highest_account=highest_account,
                               tier_labels=list(tier_data.keys()), tier_values=list(tier_data.values()),
                               top_growth_labels=top_growth_df['BucketName'].tolist(), top_growth_values=top_growth_df['Growth_GB'].tolist(), top_n=top_n)
    except Exception as e:
        app.logger.error(f"Error generating S3 dashboard: {e}")
        flash("An error occurred while processing the combined Storage Lens data.", "danger")
        return redirect(url_for('index'))

@app.route('/export-capacity-report')
@login_required
def export_capacity_report():
    df = get_combined_lens_data()
    
    if df is None or df.empty:
        flash("No Storage Lens data to export.", "warning")
        return redirect(url_for('s3_dashboard'))

    try:
        summary_df = pd.DataFrame({
            'Metric': ['Total S3 Capacity (GB)', 'Highest Capacity Account'],
            'Value': [round(df['Total_Size_GB'].sum(), 2), df.groupby('AccountId')['Total_Size_GB'].sum().idxmax()]
        })

        tiers = ['DEEP_ARCHIVE_GB', 'GLACIER_IR_GB', 'INTELLIGENT_TIERING_GB', 'ONEZONE_IA_GB', 'STANDARD_GB', 'STANDARD_IA_GB']
        tier_data = {'Storage Tier': [t for t in tiers if t in df.columns], 'Total Capacity (GB)': [round(df[t].sum(), 2) for t in tiers if t in df.columns]}
        tiers_df = pd.DataFrame(tier_data)

        available_cols = [c for c in ['AccountId', 'BucketName', 'Total_Size_GB', 'Growth_GB', '30-day%Growth'] if c in df.columns]
        
        if 'Growth_GB' in df.columns:
            top_growth_df = df.nlargest(20, 'Growth_GB')[available_cols]
        else:
            top_growth_df = pd.DataFrame(columns=available_cols)

        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
            tiers_df.to_excel(writer, sheet_name='Capacity By Tier', index=False)
            top_growth_df.to_excel(writer, sheet_name='Top 20 Growth', index=False)
            df.to_excel(writer, sheet_name='Raw Data', index=False)

        output.seek(0)
        filename = f"S3_Combined_Capacity_Report_{datetime.today().strftime('%Y-%m-%d')}.xlsx"
        return send_file(output, download_name=filename, as_attachment=True)
    except Exception as e:
        app.logger.error(f"Error generating Excel: {e}")
        return redirect(url_for('s3_dashboard'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
